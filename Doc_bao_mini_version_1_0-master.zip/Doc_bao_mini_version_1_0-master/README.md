# Doc_bao_mini_version_1_0
Sử dụng XmlPullParser để lấy tin tức

Dùng ListView để hiển thị tin tức lên màn hình

Sử dụng giao diện để đọc báo được trên nhiều trang web và chủ đề khác nhau
